﻿function OutputCompileSummary {

############ Display output information ################
Write-Host "" 
Write-Host "Be sure to review the CompileSuccess.txt and CompileFailures.txt to see if any folders need it reran."
Write-Host ""
Write-Host "Make sure the files were correctly converted."
Write-Host ""
Write-Host -Fore Green "Work Complete ..."
Start-Sleep -s 15
########################################################


}