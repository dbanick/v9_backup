﻿function OutputSummary {
    Write-Host ""
    Write-Host "The CSV folder should be compressed and copied up to your laptop to C:\Navisite\Powershell"    
    Write-Host "Then unzip and use the Compile script locally to generate a summary spreadsheet"
    Write-Host ""
    Write-Host -Fore Green "Work Complete ..."
    Start-Sleep -s 5
}