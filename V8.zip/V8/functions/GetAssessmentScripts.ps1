﻿function GetAssessmentScripts {
<#
#FULL
ALL

#CONFIG
1,2,17,8,16,10,18,21,24,22,44,45,46, 47,48, 90, 92, 112, 115, 114


#PERFORMANCE
SQL Server Memory Dumps
System Memory
Process Memory
Ring Buffer Memory Warnings
Buffer Usage by Database
PLE
Memory Clerks
Plan Cache Detail
CPU Utilization
CPU Utilization by Database
Signal Waits
Wait Types
Latch Types
IO Utilization by Database
Database Volume Information
Database Latency
Volume Latency
VLF Count
Untrusted Fgn Key Constraints
Untrusted Check Constraints
Top Worker Time Queries
Top Logical Reads Queries
Top Avg Elapsed Time Queries
Hypothetical Indexes
Most Costly Unused Indexes
Missing Indexes
Missing Index Warnings
Statistics Health
Index Fragmentation
Active Heaps
Duplicate Indexes
Overlapping Indexes

#CUSTOM

#>

}