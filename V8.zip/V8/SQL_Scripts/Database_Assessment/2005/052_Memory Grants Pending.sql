
/* Memory Grants Pending */
/* This should be trended for maximum diagnostic benefit */
SELECT @@SERVERNAME AS [Server Name], object_name AS [Object Name], cntr_value AS [Memory Grants Pending], CURRENT_TIMESTAMP AS [Collection Time]                                                                                                       
FROM sys.dm_os_performance_counters WITH (NOLOCK)
WHERE counter_name = N'Memory Grants Pending' OPTION (RECOMPILE);
