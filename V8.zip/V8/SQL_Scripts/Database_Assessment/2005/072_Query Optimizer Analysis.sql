
/* Query Optimizer Analysis */
SELECT @@SERVERNAME AS [Server Name], [counter] AS [Counter Name], occurrence AS [Occurrence], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_query_optimizer_info
WHERE counter in ('order hint','join hint') AND occurrence > 0 OPTION (RECOMPILE);
