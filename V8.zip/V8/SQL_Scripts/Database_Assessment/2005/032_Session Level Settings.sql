
/* ----------------------------------------------------------------------------------------------------------
Sessions and Connections
---------------------------------------------------------------------------------------------------------- */

/* Session level settings */
SELECT
		@@SERVERNAME AS [Server Name],
		des.session_id AS [Session ID],
		DB_NAME(der.database_id) AS [Database Name],
		des.is_user_process AS [Is User Process],
		des.text_size,
        des.language,
        des.date_format,
        des.date_first,
        des.quoted_identifier,
        des.arithabort,
        des.ansi_null_dflt_on,
        des.ansi_defaults,
        des.ansi_warnings,
        des.ansi_padding, 
        des.ansi_nulls,
        des.concat_null_yields_null,
        des.transaction_isolation_level,
        des.lock_timeout,
        des.deadlock_priority,
		CURRENT_TIMESTAMP AS [Collection Time] 
FROM    sys.dm_exec_sessions des
		LEFT JOIN sys.dm_exec_requests der
						ON des.session_id = der.session_id OPTION (RECOMPILE);
