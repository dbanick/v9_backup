
/* Instance Configuration Settings */
SELECT @@SERVERNAME AS [Server Name], name AS [Name], value AS [Value], value_in_use AS [Value in Use], 
is_advanced AS [Is Advanced], is_dynamic AS [Is Dynamic],  [description] AS [Description], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.configurations
ORDER BY name OPTION (RECOMPILE);
