
/* SQL Agent Operators */
SELECT @@SERVERNAME AS [Server Name], name AS [Name], email_address AS [Email Address], [enabled] AS [Enabled], CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb..sysoperators OPTION (RECOMPILE);
