/* Forwarding Pointers */
CREATE TABLE #rdxresults
    (
	  [Server Name] VARCHAR(255),
       [Database Name] VARCHAR(255),
	  [Object Name] VARCHAR(255),
	  [Index ID] BIGINT,
	  [Partition Number] BIGINT,
	  [Row Count] BIGINT,
	  [Forwarded Fetch Count] BIGINT,
	  [Collection Time] DATETIME
    );
EXEC dbo.sp_MSforeachdb 'USE [?]; 
INSERT INTO #rdxresults 
SELECT	
	@@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
	''['' + SCHEMA_NAME(so.[schema_id]) + ''].['' + OBJECT_NAME(so.[object_id]) + '']'' AS [Object Name],
	ps.index_id AS [Index ID], 
	ps.partition_number AS [Partition Number], 
	ps.row_count AS [Row Count],
	os.forwarded_fetch_count AS [Forwarded Fetch Count],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_db_partition_stats AS ps  
JOIN sys.partitions AS par ON ps.partition_id = par.partition_id
JOIN sys.objects AS so ON ps.object_id = so.object_id
	AND so.is_ms_shipped = 0
	AND so.[type] <> ''TF''
LEFT JOIN sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL,NULL) AS os ON ps.object_id = os.object_id 
	AND ps.index_id = os.index_id 
	AND ps.partition_number = os.partition_number 
WHERE os.forwarded_fetch_count > 0
ORDER BY ps.[object_id], ps.index_id, ps.partition_number
OPTION (RECOMPILE)';
SELECT * FROM #rdxresults WHERE [Database Name] NOT IN ('tempdb')
DROP TABLE #rdxresults;