
/* Check for plan guides in database */
CREATE TABLE #results
(
	[Server Name] VARCHAR(255),
    [Database Name] VARCHAR(255),
	[Plan Guide Name] VARCHAR(255),
	[Query Text] VARCHAR(255),
	[Hints] VARCHAR(255),
	[Created On] DATETIME,
	[Collection Time] DATETIME
);
INSERT INTO #results
EXEC sp_MSforeachdb 'USE [?];
	SELECT @@SERVERNAME AS [Server Name]
	,db_name() AS [Database Name]
	,name AS [Plan Guide Name]
	,query_text AS [Query Text]
	,hints AS [Hints]
	,create_date AS [Created On]
	,CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.plan_guides WHERE is_disabled = 0 OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Database Name]
DROP TABLE #results
