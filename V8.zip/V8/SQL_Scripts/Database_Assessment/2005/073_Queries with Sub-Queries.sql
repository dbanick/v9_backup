
/* Fractions of Optimized Queries Containing Subqueries */
SELECT 
	@@SERVERNAME AS [Server Name],
	(SELECT CAST (occurrence AS float) FROM sys.dm_exec_query_optimizer_info WHERE counter = 'contains subquery') /(SELECT CAST (occurrence AS float) 
FROM sys.dm_exec_query_optimizer_info WHERE counter = 'optimizations') AS [Fraction Containing Subqueries], CURRENT_TIMESTAMP AS [Collection Time] OPTION (RECOMPILE);
