
/* Index Fragmentation */
DECLARE @ver DECIMAL(4,2)
SET @ver = SUBSTRING(CAST(serverproperty('ProductVersion') AS nvarchar), 1,4)
print @ver
IF ( @ver >= '10.00' )
begin
/*2008 and above */
execute('CREATE TABLE #rdxresults
	(
		[Server Name] varchar(255),
		[Database Name] varchar(255),
		[Object Name] varchar(255),
		[Index Name] varchar(255),
		[Index ID] int,
		[Index Type] varchar(255),
		[% Fragmentation] varchar(255),
		[Fragment Count] int,
		[Page Count] int,
		[Original Fill Factor] varchar(255),
		[Avg Page Space Used %] varchar(255)
	)
INSERT INTO #rdxresults
EXEC sp_MSforeachdb @command1 = ''USE [?];
SELECT @@SERVERNAME AS [Server Name], DB_NAME(database_id) AS [Database Name], OBJECT_NAME(ps.object_id) AS [Object Name], 
i.name AS [Index Name], ps.index_id AS [Index ID], index_type_desc AS [Index Type],
avg_fragmentation_in_percent AS [% Fragmentation], fragment_count AS [Fragment Count], page_count AS [Page Count],i.fill_factor AS [Original Fill Factor],
ps.avg_page_space_used_in_percent AS [Avg Page Space Used %]
--FROM sys.dm_db_index_physical_stats(DB_ID(),NULL, NULL, NULL ,''''SAMPLED'''') AS ps 
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL, NULL, NULL ,''''LIMITED'''') AS ps 
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON ps.[object_id] = i.[object_id] 
AND ps.index_id = i.index_id
WHERE database_id = DB_ID()
--AND page_count >= 1000
AND page_count >= 2500
ORDER BY avg_fragmentation_in_percent DESC OPTION (RECOMPILE);''
SELECT * from #rdxresults;
DROP TABLE #rdxresults;')
end
else 
SELECT 'Unsupported SQL Server Version'  as [Error]