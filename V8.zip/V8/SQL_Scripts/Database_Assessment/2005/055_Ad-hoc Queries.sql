
/* Single Use Ad-hoc Plans */
SELECT TOP(25) @@SERVERNAME AS [Server Name], left([text],1500) AS [Query Text], cp.size_in_bytes AS [Size in Bytes], cp.size_in_bytes / 1024 AS [Size in KB], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE cp.cacheobjtype = N'Compiled Plan' 
AND cp.objtype = N'Adhoc' 
AND cp.usecounts = 1
ORDER BY cp.size_in_bytes DESC OPTION (RECOMPILE);
