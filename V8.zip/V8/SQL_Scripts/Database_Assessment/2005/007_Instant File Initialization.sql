
/* Instant File Initialization is Enabled */
CREATE TABLE #RDXResults
	([Output] VARCHAR(255));
begin try
INSERT INTO #RDXResults
EXEC xp_cmdshell 'whoami /priv';
end try
begin catch
INSERT INTO #RDXResults
SELECT 'Error occured. Please manually check via local security policy. '  as [Output]
end catch
SELECT @@SERVERNAME AS [Server Name], [Output] AS [Privileges Information], CURRENT_TIMESTAMP AS [Collection Time]
FROM #RDXResults WHERE [output] IS NOT NULL;
DROP TABLE #RDXResults;
