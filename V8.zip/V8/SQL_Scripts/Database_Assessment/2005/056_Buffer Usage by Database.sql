
/* Buffer Usage by Database */
SELECT
	@@SERVERNAME AS [Server Name],
   (CASE WHEN ([database_id] = 32767)
       THEN 'Resource Database'
       ELSE DB_NAME ([database_id]) END) AS [Database Name],
   COUNT (*) * 8 / 1024 AS [MB Used],
   SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024) AS [MB Empty],
   CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_os_buffer_descriptors
GROUP BY [database_id]
ORDER BY [MB Used] DESC OPTION (RECOMPILE);
