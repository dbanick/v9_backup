
/* Memory Clerks */
SELECT TOP(10) 
	@@SERVERNAME AS [Server Name],
	[type] AS [Memory Clerk Type], 
	SUM(single_pages_kb) AS [SPA in KB], 
	CONVERT(DECIMAL(12,1),SUM(single_pages_kb)) / 1024 AS [SPA in MB], 
	CONVERT(DECIMAL(12,1),SUM(single_pages_kb)) / 1024 / 1024 AS [SPA in GB],
	CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_os_memory_clerks WITH (NOLOCK)
GROUP BY [type]  
ORDER BY SUM(single_pages_kb) DESC OPTION (RECOMPILE);
