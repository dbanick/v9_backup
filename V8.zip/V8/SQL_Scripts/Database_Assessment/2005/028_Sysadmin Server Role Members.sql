
/* Sysadmin & Security Server Role Member */
SELECT
	@@SERVERNAME AS [Server Name],
    loginname AS [Login Name],
    sysadmin AS [Sysadmin],
    securityadmin AS [Security Admin],
    isntuser AS [Is NT User],
    isntgroup AS [Is NT Group],
    createdate AS [Create Date],
    updatedate AS [Update Date],
    hasaccess AS [Has Access],
	CURRENT_TIMESTAMP AS [Collection Time] 
FROM
    master..syslogins
WHERE
    sysadmin = 1 or securityadmin = 1 OPTION (RECOMPILE);
  