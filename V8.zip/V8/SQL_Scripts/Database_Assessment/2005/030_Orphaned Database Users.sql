
/* Orphaned Database Users */
CREATE TABLE #rdxoutput
    (
      [Server Name] VARCHAR(MAX),
      [Database Name] VARCHAR(MAX),
      [User Name] VARCHAR(MAX),
      [User Type] VARCHAR(MAX),
      [Default Schema Name] VARCHAR(MAX),
      [Create Date] DATETIME,
      [Modify Date] DATETIME,
	  [Collection Time] DATETIME
    );  
INSERT INTO #rdxoutput
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT
	@@SERVERNAME as [Server Name], 
	''?'' as [Database Name],
	name as [User Name],
	type_desc as [User Type],
	default_schema_name as [Default Schema Name],
	create_date as [Create Date],
	modify_date as [Modify Date],
	CURRENT_TIMESTAMP as [Collection Time]
FROM sys.database_principals 
WHERE TYPE IN (''G'',''S'',''U'') 
AND [sid] NOT IN (SELECT [sid] FROM sys.server_principals WHERE type IN (''G'',''S'',''U'')) 
AND name NOT IN (''dbo'',''guest'',''INFORMATION_SCHEMA'',''sys'',''MS_DataCollectorInternalUser'');'
SELECT * FROM #rdxoutput ORDER BY [Database Name];
DROP TABLE #rdxoutput;
