
/* Check for global trace flags */
DBCC TRACESTATUS (-1);
