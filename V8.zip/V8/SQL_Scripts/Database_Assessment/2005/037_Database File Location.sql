
/* Database File Location */
SELECT
	@@SERVERNAME AS [Server Name],
    db.name AS [Database Name],
	db.state_desc AS [Database State],
    mf.[file_id] AS [File ID],
    mf.name AS [Name],
    mf.physical_name AS [Physical Name],
    mf.type_desc AS [Type Description],
    mf.state_desc AS [File State],
    mf.SIZE AS [Number of 8K Pages],
    CONVERT(BIGINT, mf.size / 128.0) AS [Total Size in MB],
	CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.master_files AS mf
	LEFT JOIN sys.databases AS db WITH (NOLOCK) ON mf.database_id = db.database_id
ORDER BY db.name
OPTION (RECOMPILE);
    