
/* SQL Server Ring Buffer Out of Memory Errors */
WITH cRingBufferOOM
AS (
SELECT CAST (record AS xml) record_xml, timestamp FROM sys.dm_os_ring_buffers AS dorb
WHERE ring_buffer_type = 'RING_BUFFER_OOM'
)
SELECT
@@SERVERNAME AS [Server Name]
,rx.value('(@id)[1]', 'BIGINT') AS RecordID
,DATEADD (ss, (-1 * ((osi.cpu_ticks / CONVERT (float, ( osi.cpu_ticks / osi.ms_ticks ))) - [timestamp])/1000), CURRENT_TIMESTAMP) AS DateOccurred
,rx.value('(OOM/Action)[1]', 'VARCHAR(30)') AS MemoryAction
,rx.value('(OOM/Pool)[1]', 'INT') AS MemoryPool
,rx.value('(MemoryNode/SharedMemory)[1]', 'BIGINT')/1024 AS SharedMemoryMB
,rx.value('(MemoryNode/AWEMemory)[1]', 'BIGINT')/1024 AS AWEMemoryMB
,rx.value('(MemoryNode/SinglePagesMemory)[1]', 'BIGINT')/1024 AS SinglePagesMemoryMB
,rx.value('(MemoryNode/MultiplePagesMemory)[1]', 'BIGINT')/1024 AS MultiplePagesMemoryMB
,rx.value('(MemoryNode/@id)[1]', 'BIGINT') AS NodeID
,rx.value('(MemoryNode/ReservedMemory)[1]', 'BIGINT')/1024 AS SQL_ReservedMemoryMB
,rx.value('(MemoryNode/CommittedMemory)[1]', 'BIGINT')/1024 AS SQL_CommittedMemoryMB
,rx.value('(MemoryRecord/MemoryUtilization)[1]', 'BIGINT') AS MemoryUtilization
,rx.value('(MemoryRecord/TotalPhysicalMemory)[1]', 'BIGINT')/1024 AS TotalPhysicalMemoryMB
,rx.value('(MemoryRecord/AvailablePhysicalMemory)[1]', 'BIGINT')/1024 AS AvailablePhysicalMemoryMB
,rx.value('(MemoryRecord/TotalPageFile)[1]', 'BIGINT')/1024 AS TotalPageFileMB
,rx.value('(MemoryRecord/AvailablePageFile)[1]', 'BIGINT')/1024 AS AvailablePageFileMB
,rx.value('(MemoryRecord/TotalVirtualAddressSpace)[1]', 'BIGINT')/1024 AS TotalVASMB
,rx.value('(MemoryRecord/AvailableExtendedVirtualAddressSpace)[1]', 'BIGINT')/1024 AS AvailableExtendedVASMB
,CURRENT_TIMESTAMP AS [Collection Time]
FROM cRingBufferOOM rbo
CROSS APPLY rbo.record_xml.nodes('Record') record(rx)
CROSS JOIN sys.dm_os_sys_info osi
ORDER BY rx.value('(@id)[1]', 'BIGINT')
