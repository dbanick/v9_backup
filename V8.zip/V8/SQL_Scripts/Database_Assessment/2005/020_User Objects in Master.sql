
/* User Objects in Master Database */
SELECT @@SERVERNAME AS [Server Name], name AS [Table Name], create_date AS [Date Created], CURRENT_TIMESTAMP AS [Collection Time]
FROM master.sys.tables
WHERE is_ms_shipped = 0 OPTION (RECOMPILE);
