
/* Deadlock Count */
/* This is the deadlock count since startup */
SELECT
	@@SERVERNAME AS [Server Name],
	'There have been' + CAST(p.cntr_value AS NVARCHAR(100)) + ' deadlocks recorded since SQL Server startup.' AS [Message],
	DATEDIFF(DD,create_date,CURRENT_TIMESTAMP) AS [Days since SQL Server Startup],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_os_performance_counters p
	INNER JOIN sys.databases d ON d.name = 'tempdb'
WHERE RTRIM(p.counter_name) = 'Number of Deadlocks/sec'
	AND RTRIM(p.instance_name) = '_Total'
	AND p.cntr_value > 0
	AND (1.0 * p.cntr_value / NULLIF(datediff(DD,create_date,CURRENT_TIMESTAMP),0)) > 10;
