
/* Plan Cache Detail */
SELECT
	@@SERVERNAME AS [Server Name],
    objtype AS [Cache Type] ,
    COUNT_BIG(*) AS [Total Plans] ,
    SUM(CAST(size_in_bytes AS DECIMAL(12, 2))) / 1024 / 1024 AS [Total MB] ,
    AVG(usecounts) AS [Avg Use Count] ,
    SUM(CAST(( CASE WHEN usecounts = 1 THEN size_in_bytes
                    ELSE 0
               END ) AS DECIMAL(12, 2))) / 1024 / 1024 AS [Total MB - Use Count 1] ,
    SUM(CASE WHEN usecounts = 1 THEN 1
             ELSE 0
        END) AS [Total Plans - Use Count 1],
    CURRENT_TIMESTAMP AS [Collection Time] 
FROM
    sys.dm_exec_cached_plans
GROUP BY
    objtype
ORDER BY
    [Total MB - Use Count 1] DESC OPTION (RECOMPILE);
