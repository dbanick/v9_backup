
/* Elapsed Time per Optimization */
SELECT @@SERVERNAME AS [Server Name], ISNULL(value,0.0) AS [Elapsed Time Per Optimization], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_exec_query_optimizer_info WHERE counter = 'elapsed time' OPTION (RECOMPILE);
