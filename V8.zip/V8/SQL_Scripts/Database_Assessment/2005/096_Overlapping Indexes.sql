
/* Overlapping Indexes */
/* 
	- This query finds partial, or duplicate, indexes that share leading key columns.
	- This query only examines key columns and does not consider included columns.
	- This has numerous columns commented out. You can uncomment these to double check the results.
	- Removed bug that did not join based on database id which led to false positives.
*/
/* http://sqlblog.com/blogs/paul_nielsen/archive/2008/06/25/find-duplicate-indexes.aspx */

CREATE TABLE #rdxresults
	(
		[Server Name] VARCHAR(255),
		[Database Name] VARCHAR(255),
		[database_id] BIGINT,
		[Table Name] VARCHAR(255),
		id BIGINT,
		indid BIGINT,
		name VARCHAR(MAX),
		cols VARCHAR(255)
	)
INSERT INTO #rdxresults
EXEC sp_MSforeachdb 'USE [?]; 
SELECT 
	@@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
	DB_ID() AS [database_id],
	object_schema_name(object_id,DB_ID()) + ''.'' + OBJECT_NAME(object_id,DB_ID()) AS [Table Name],
	object_id AS id, index_id AS indid, name,
	(select case keyno when 0 then NULL else colid end AS [data()]
FROM sys.sysindexkeys AS k
WHERE k.id = i.object_id
AND k.indid = i.index_id
ORDER BY keyno, colid
FOR XML PATH ('''')) AS cols
FROM sys.indexes AS i';
SELECT
	c1.[Server Name],
	c1.[Database Name] AS [Database],
	c1.[Table Name],
	c1.name AS [Index Name],
	c2.name AS [Overlapping Index Name],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM #rdxresults AS c1
	JOIN #rdxresults AS c2 ON c1.id = c2.id 
	AND c1.database_id = c2.database_id
	AND c1.indid < c2.indid
	AND ((c1.cols like c2.cols + '%' AND SUBSTRING(c1.cols,LEN(c2.cols)+1,1) = ' ')
	OR (c2.cols like c1.cols + '%' AND SUBSTRING(c2.cols,LEN(c1.cols)+1,1) = ' '))
WHERE c1.[Database Name] NOT IN ('master','model','msdb','tempdb','distribution')
ORDER BY c1.[Database Name], c1.[Table Name] OPTION (RECOMPILE);
DROP TABLE #rdxresults
