
/* VLF Count */
/* We return databases with VLF counts of 500 or more but we're only concerned with counts of 1000 or more */
CREATE TABLE #stage
    (
      FileID INT,
      FileSize BIGINT,
      StartOffset BIGINT,
      FSeqNo BIGINT,
      [Status] BIGINT,
      Parity BIGINT,
      CreateLSN NUMERIC(38)
    );
CREATE TABLE #results
    (
      Database_Name SYSNAME,
      VLF_count INT
    );
EXEC sp_MSforeachdb N'Use [?]; 
            INSERT INTO #stage 
            exec (''DBCC LOGINFO([?])''); 
            Insert Into #results 
            Select DB_Name(), Count(*) 
            From #stage; 
            Truncate Table #stage;'
SELECT  @@SERVERNAME AS [Server Name], Database_Name AS [Database Name], VLF_count AS [VLF Count], CURRENT_TIMESTAMP AS [Collection Time] 
FROM    #results
WHERE VLF_count >= 500
ORDER BY VLF_count DESC;
DROP TABLE #stage;
DROP TABLE #results;
