
/* Foreign keys with non-default update and delete actions */
CREATE TABLE #rdxresults
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Foreign Key Name] VARCHAR(255),
	  [Delete Action] VARCHAR(255),
	  [Update Action] VARCHAR(255),
	  [Collection Time] DATETIME
    );
INSERT INTO #rdxresults
exec sp_MSforeachdb 'USE [?];
	SELECT @@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
	SCHEMA_NAME(schema_id) + ''.'' + name AS [Foreign Key Name],
	delete_referential_action_desc AS [Delete Action],
	update_referential_action_desc AS [Update Action],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.foreign_keys
WHERE delete_referential_action_desc <> ''NO_ACTION''
	or update_referential_action_desc <> ''NO_ACTION'' OPTION (RECOMPILE);'
SELECT * FROM #rdxresults
DROP TABLE #rdxresults
