
/* Concurrent SQL Agent Jobs */
SELECT 
    @@SERVERNAME as [Server Name],
    j.name AS [Job Name],
    j.[description] AS [Job Description],
    a.start_execution_date AS [Start Execution Date],
    CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb.dbo.sysjobs j
    INNER JOIN msdb.dbo.sysjobactivity a ON j.job_id = a.job_id
WHERE a.start_execution_date > DATEADD(dd, -14, CURRENT_TIMESTAMP)
AND j.[enabled] = 1
AND a.start_execution_date IN
   (SELECT start_execution_date
    FROM msdb.dbo.sysjobactivity
    WHERE start_execution_date > DATEADD(dd, -14, CURRENT_TIMESTAMP)
    GROUP BY start_execution_date HAVING COUNT(*) > 1)
ORDER BY a.start_execution_date;
