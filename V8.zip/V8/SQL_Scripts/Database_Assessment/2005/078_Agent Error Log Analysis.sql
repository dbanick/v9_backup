/* SQL Server Agent Error Log Analysis */
CREATE TABLE #results
    (
	  [Log Date] DATETIME,
      [Error Level] INT,
	  [Text] VARCHAR(5000)
    ) ;
INSERT INTO #results execute xp_readerrorlog 0, 2
SELECT @@SERVERNAME AS [Server Name], [Log Date], [Error Level], [Text], CURRENT_TIMESTAMP AS [Collection Time] FROM #results ORDER BY [Log Date] DESC
DROP TABLE #results
