/* Extended Events Analysis */
/* 2008 and newer */
SELECT CAST(xest.target_data as XML) xml_data, * 
INTO #ring_buffer_data 
FROM  
   sys.dm_xe_session_targets xest 
   INNER JOIN sys.dm_xe_sessions xes on xes.[address] = xest.event_session_address 
WHERE  
   xest.target_name = 'ring_buffer' AND  
   xes.name = 'system_health' 
;WITH CTE( event_name, event_time, deadlock_graph ) 
AS 
( 
   SELECT 
       event_xml.value('(./@name)', 'varchar(1000)') as [Event Name], 
       event_xml.value('(./@timestamp)', 'datetime') as [Event Time], 
       event_xml.value('(./data[@name="xml_report"]/value)[1]', 'varchar(max)') as [Deadlock Graph] 
   FROM #ring_buffer_data 
       CROSS APPLY xml_data.nodes('//event[@name="xml_deadlock_report"]') n (event_xml) 
   WHERE event_xml.value('@name', 'varchar(4000)') = 'xml_deadlock_report' 
) 
SELECT @@SERVERNAME AS [Server Name], event_name AS [Event Name], event_time AS [Event Time],  
    CAST( deadlock_graph AS XML) AS [Deadlock Graph] 
FROM CTE 
ORDER BY event_time DESC 
DROP TABLE #ring_buffer_data