use [master]
go
exec xp_msver
go