
/* Checkdb History */
CREATE TABLE #DBCCs
        (
          Id INT IDENTITY(1, 1)
          PRIMARY KEY ,
          ParentObject VARCHAR(255) ,
          Object VARCHAR(255) ,
          Field VARCHAR(255) ,
          Value VARCHAR(255) ,
          DbName SYSNAME NULL
        )
    EXEC sp_MSforeachdb N'USE [?];
							INSERT #DBCCs(ParentObject, Object, Field, Value)
							EXEC (''DBCC DBInfo() With TableResults, NO_INFOMSGS'');
							UPDATE #DBCCs SET DbName = N''?'' WHERE DbName IS NULL;';
    WITH    DB2
              AS ( SELECT   DISTINCT
                            Field ,
                            Value ,
                            DbName
                   FROM     #DBCCs
                   WHERE    Field = 'dbi_dbccLastKnownGood'
                 )
        
                SELECT  @@SERVERNAME AS [Server Name],
						DB2.DbName AS [Database Name],
                        DB2.Value AS [Last CHECKDB], 
						CURRENT_TIMESTAMP AS [Collection Time]
                FROM    DB2 
				where dbname not in ('tempdb')
				ORDER BY 3 DESC
				OPTION (RECOMPILE);
DROP TABLE #DBCCs
