
/* SPs by Total Logical Writes */
CREATE TABLE #results
(
	[Server Name] VARCHAR(255),
     [Database Name] VARCHAR(255),
	[SP Name] VARCHAR(1000),
	[Total Logical Writes] BIGINT,
	[Avg Logical Writes] BIGINT,
	[Execution Count] BIGINT,
	[Calls/Second] BIGINT,
	[Total Elapsed Time] BIGINT,
	[Avg Elapsed Time] BIGINT,
	[Cache Time] DATETIME,
	[Collection Time] DATETIME
);
INSERT INTO #results	
exec sp_MSforeachdb @command1 = 'USE [?];
SELECT TOP(10) @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], left(p.name,1000) AS [SP Name], qs.total_logical_writes AS [Total Logical Writes], 
qs.total_logical_writes/qs.execution_count AS [Avg Logical Writes], qs.execution_count AS [Execution Count],
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, CURRENT_TIMESTAMP), 0) AS [Calls/Second],
qs.total_elapsed_time AS [Total Elapsed Time], qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time], 
qs.cached_time AS [Cached Time], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.procedures AS p
INNER JOIN sys.dm_exec_procedure_stats AS qs
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_logical_writes DESC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Total Logical Writes] DESC
DROP TABLE #results
	