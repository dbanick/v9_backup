
/* SQL Server Services Information */
SELECT @@SERVERNAME AS [Server Name], servicename AS [Service Name], startup_type_desc AS [Startup Type], status_desc AS [Status], 
last_startup_time AS [Last Startup Time], service_account AS [Service Account], is_clustered AS [Is Clustered], cluster_nodename AS [Clustered Node Name], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_server_services OPTION (RECOMPILE);
