
/* SQL Server Memory Dumps */
SELECT @@SERVERNAME AS [Server Name], [filename] AS [File Name], creation_time AS [Creation Time], size_in_bytes AS [Size in Bytes], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_server_memory_dumps WITH (NOLOCK) OPTION (RECOMPILE);
