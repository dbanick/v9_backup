
/* Windows Information */
SELECT @@SERVERNAME AS [Server Name], windows_release AS [Windows Release], windows_service_pack_level AS [Windows Service Pack Level], 
       windows_sku AS [Windows SKU], os_language_version AS [OS Language Version], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_os_windows_info OPTION (RECOMPILE);
