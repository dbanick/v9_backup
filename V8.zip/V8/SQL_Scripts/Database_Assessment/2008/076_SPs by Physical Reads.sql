
/* SPs by Total Physical Reads */
CREATE TABLE #results
(
	[Server Name] VARCHAR(255),
     [Database Name] VARCHAR(255),
	[SP Name] VARCHAR(1000),
	[Total Physical Reads] BIGINT,
	[Avg Physical Reads] BIGINT,
	[Execution Count] BIGINT,
	[Total Logical Reads] BIGINT,
	[Total Elapsed Time] BIGINT,
	[Avg Elapsed Time] BIGINT,
	[Cached Time] DATETIME,
	[Collection Time] DATETIME
);
INSERT INTO #results
exec sp_MSforeachdb @command1 = 'USE [?];
SELECT TOP(10) @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], left(p.name,1000) AS [SP Name],qs.total_physical_reads AS [Total Physical Reads], 
qs.total_physical_reads/qs.execution_count AS [Avg Physical Reads], qs.execution_count AS [Execution Count], 
qs.total_logical_reads [Total Logical Reads],qs.total_elapsed_time AS [Total Elapsed Time], qs.total_elapsed_time/qs.execution_count 
AS [Avg Elapsed Time], qs.cached_time AS [Cached Time], CURRENT_TIMESTAMP AS [Collection Time]  
FROM sys.procedures AS p
INNER JOIN sys.dm_exec_procedure_stats AS qs
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
AND qs.total_physical_reads > 0
ORDER BY qs.total_physical_reads DESC, qs.total_logical_reads DESC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Total Physical Reads] DESC
DROP TABLE #results
