/* SQL Agent Jobs */
SELECT @@SERVERNAME AS [Server Name]
	,j.name AS [Job Name]
	,j.description AS [Job Description]
	,sc.name AS [Job Category]
	,SUSER_SNAME(j.owner_sid) AS [Job Owner]
	,CASE j.enabled
		WHEN 1 THEN 'Enabled'
		ELSE 'Disabled'
	 END AS [Job Status]
	,CASE j.notify_level_email
		WHEN 1 THEN 'Success'
		WHEN 2 THEN 'Failure'
		WHEN 3 THEN 'Completion'
		ELSE 'None'
	 END AS [Notify On]
	,o.name AS [Operator]
	,CASE jh.run_status
		WHEN 0 THEN 'Error Failed'
		WHEN 1 THEN 'Succeeded'
		WHEN 2 THEN 'Retry'
		WHEN 3 THEN 'Cancelled'
		WHEN 4 THEN 'In Progress'
		ELSE 'Status Unknown'
	 END AS 'Last Run Status'
	,ja.run_requested_date AS [Last Run Date]
	,CONVERT(VARCHAR(10), CONVERT(DATETIME, RTRIM(19000101)) + (jh.run_duration * 9 + jh.run_duration % 10000 * 6 + jh.run_duration % 100 * 10) / 216e4, 108) AS [Run Duration]
	,ja.next_scheduled_run_date AS [Next Scheduled Run Date]
	,CONVERT(VARCHAR(500), jh.message) AS [Step Description]
	,CURRENT_TIMESTAMP AS [Collection Time]
FROM (
	msdb.dbo.sysjobactivity ja LEFT JOIN msdb.dbo.sysjobhistory jh WITH (NOLOCK) ON ja.job_history_id = jh.instance_id
	)
JOIN msdb.dbo.sysjobs_view j WITH (NOLOCK) ON ja.job_id = j.job_id
INNER JOIN msdb.dbo.syscategories AS sc WITH (NOLOCK) ON j.category_id = sc.category_id
LEFT JOIN msdb.dbo.sysoperators o ON o.id = j.notify_email_operator_id
WHERE ja.session_id = (
		SELECT MAX(session_id)
		FROM msdb.dbo.sysjobactivity
		)
ORDER BY [Job Name]
	,[Job Status]
OPTION (RECOMPILE);

