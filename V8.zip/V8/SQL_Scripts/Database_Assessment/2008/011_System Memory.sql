
/* System Memory Information */
/* Checks for external memory pressure */
SELECT @@SERVERNAME AS [Server Name], total_physical_memory_kb, available_physical_memory_kb, 
       total_page_file_kb, available_page_file_kb, system_memory_state_desc, CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_os_sys_memory OPTION (RECOMPILE);
