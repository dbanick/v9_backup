
/* Startup stored procedures in master */
USE master
SELECT
	@@SERVERNAME AS [Server Name],
    '[master].[' + r.SPECIFIC_SCHEMA + '].[' + r.SPECIFIC_NAME + ']' AS [Procedure Name], CURRENT_TIMESTAMP AS [Collection Time]
FROM master.INFORMATION_SCHEMA.ROUTINES r
WHERE OBJECTPROPERTY(OBJECT_ID(r.ROUTINE_NAME), 'ExecIsStartup') = 1;
