
/* CPU Utilization History (last 144 minutes in one minute intervals) */
DECLARE @ts_now BIGINT = ( SELECT
							cpu_ticks / ( cpu_ticks / ms_ticks )
							FROM
							sys.dm_os_sys_info
							) ; 
SELECT TOP ( 144 )
	@@SERVERNAME AS [Server Name],
	SQLProcessUtilization AS [SQL Server Process CPU Utilization] ,
	SystemIdle AS [System Idle Process] ,
	100 - SystemIdle - SQLProcessUtilization AS [Other Process CPU Utilization] ,
	DATEADD(ms, -1 * ( @ts_now - [timestamp] ), CURRENT_TIMESTAMP) AS [Event Time],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM
	( SELECT
		record.value('(./Record/@id)[1]', 'INT') AS record_id ,
		record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]',
						'INT') AS [SystemIdle] ,
		record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]',
						'INT') AS [SQLProcessUtilization] ,
		[timestamp]
		FROM
		( SELECT
			[timestamp] ,
			CONVERT(XML, record) AS [record]
			FROM
			sys.dm_os_ring_buffers
			WHERE
			ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			AND record LIKE N'%<SystemHealth>%'
		) AS x
	) AS y
ORDER BY
	record_id DESC
OPTION
	(RECOMPILE);
