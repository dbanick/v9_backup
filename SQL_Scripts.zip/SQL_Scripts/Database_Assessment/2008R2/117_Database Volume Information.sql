/* Database Volume Information */
/* 2008 R2 and newer */
SELECT DISTINCT @@SERVERNAME AS 'Server Name'
	,vs.volume_mount_point AS 'Volume'
	,vs.file_system_type AS 'Volume Type'
	,vs.logical_volume_name AS 'Logical Volume Name'
	,CONVERT(DECIMAL(18, 2), vs.total_bytes / 1073741824.0) AS [Total Size (GB)]
	,CONVERT(DECIMAL(18, 2), vs.available_bytes / 1073741824.0) AS [Available Size (GB)]
	,CONVERT(DECIMAL(18, 2), vs.available_bytes * 1. / vs.total_bytes * 100.) AS [Space Free %]
FROM sys.master_files AS f WITH (NOLOCK)
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.[file_id]) AS vs
ORDER BY vs.volume_mount_point
OPTION (RECOMPILE);