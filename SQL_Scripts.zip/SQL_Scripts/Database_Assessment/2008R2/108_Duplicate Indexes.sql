
/* Duplicate Indexes */
/* 
	- The query finds exact matches. 
	- Indexes must have the same key columns in the same order.
	- Indexes must have the same included columns but in any order. 
	- This has numerous columns commented out. You can uncomment these to double check the results.
	- Removed bug that did not join based on database id which led to false positives.
*/
/* http://sqlblog.com/blogs/paul_nielsen/archive/2008/06/25/find-duplicate-indexes.aspx */

CREATE TABLE #rdxresults
	(
		[Server Name] VARCHAR(255),
		[Database Name] VARCHAR(255),
		database_id BIGINT,
		[Table Name] VARCHAR(255),
		id BIGINT,
		indid BIGINT,
		name VARCHAR(MAX),
		cols VARCHAR(4000),
		inc VARCHAR(4000)
	)	
INSERT INTO #rdxresults
EXEC sp_MSforeachdb 'USE [?]; 
SELECT
	@@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
	DB_ID() AS database_id,
	object_schema_name(object_id,DB_ID()) + ''.'' + OBJECT_NAME(object_id,DB_ID()) AS [Table Name],
    object_id AS id ,
    index_id AS indid ,
    name ,
    ( SELECT
        CASE keyno
            WHEN 0 THEN NULL
            ELSE colid
        END AS [data()]
        FROM
        sys.sysindexkeys AS k
        WHERE
        k.id = i.object_id
        AND k.indid = i.index_id
        ORDER BY
        keyno ,
        colid
    FOR
        XML PATH('''')
    ) AS cols ,
    ( SELECT
        CASE keyno
            WHEN 0 THEN colid
            ELSE NULL
        END AS [data()]
        FROM
        sys.sysindexkeys AS k
        WHERE
        k.id = i.object_id
        AND k.indid = i.index_id
        ORDER BY
        colid
    FOR
        XML PATH('''')
    ) AS inc
    FROM
    sys.indexes AS i';
SELECT
	c1.[Server Name],
	c1.[Database Name] AS [Database],
	c1.[Table Name],
	c1.name AS [Index Name],
	c2.name AS [Duplicate Index Name],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM
    #rdxresults AS c1
    JOIN #rdxresults AS c2 ON c1.id = c2.id -- same object id
		AND c1.database_id = c2.database_id -- same database id
		AND c1.indid < c2.indid -- so we don't compare the same index to itself
		AND c1.cols = c2.cols -- same column id
		AND c1.inc = c2.inc -- same included column id
WHERE c1.[Database Name] NOT IN ('master','model','msdb','tempdb','distribution')
ORDER BY c1.[Database Name], c1.[Table Name] OPTION (RECOMPILE);
DROP TABLE #rdxresults
