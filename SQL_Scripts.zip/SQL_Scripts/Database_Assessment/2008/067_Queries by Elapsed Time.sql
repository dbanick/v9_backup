
/* Queries by Total Elapsed Time */
CREATE TABLE #RDXResults
(
	[Server Name] VARCHAR(255),
    [Database Name] VARCHAR(255),
	[Query Hash] BINARY(8),
	[Cached Plan Count] BIGINT,
	[Execution Count] BIGINT,
	[Total Elapsed Time] BIGINT,
	[Total Worker Time] BIGINT,
	[Total Logical Reads] BIGINT,
	[Total Physical Reads] BIGINT,
	[Total Logical Writes] BIGINT,
	[Object Name] VARCHAR(200),
	[Sample Query Text] VARCHAR(MAX),
	[Collection Time] DATETIME
);
INSERT INTO #RDXResults		
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT TOP (10) @@SERVERNAME, DB_NAME(), qs.query_hash, COUNT(qs.query_hash),
	SUM(qs.execution_count),SUM(qs.total_elapsed_time),SUM(qs.total_worker_time),
	SUM(qs.total_logical_reads),SUM(qs.total_physical_reads),SUM(qs.total_logical_writes),MIN(OBJECT_NAME(qt.objectid)),
	MIN(LEFT(SUBSTRING(REPLACE(REPLACE(REPLACE(qt.[text], CHAR(10), CHAR(32)), CHAR(13), CHAR(32)), CHAR(9), CHAR(32)),qs.statement_start_offset/2 +1,
		(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), REPLACE(REPLACE(REPLACE(qt.[text], CHAR(10), CHAR(32)), CHAR(13), CHAR(32)), CHAR(9), CHAR(32)))) * 2
			ELSE qs.statement_end_offset END - qs.statement_start_offset)/2),5000)) AS query_text, CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
WHERE qt.dbid = DB_ID()
GROUP BY query_hash
HAVING SUM([qs].[execution_count]) > 100
ORDER BY SUM([qs].[total_elapsed_time]) DESC OPTION (RECOMPILE);'
SELECT * FROM #RDXResults ORDER BY [Total Elapsed Time] DESC
DROP TABLE #RDXResults
