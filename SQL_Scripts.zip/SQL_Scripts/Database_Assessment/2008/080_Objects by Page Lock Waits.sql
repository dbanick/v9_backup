
/* Objects by Page Lock Waits */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Object Name] VARCHAR(255),
	  [Index ID] INT,
	  [Partition Number] INT,
	  [Page Lock Wait Count] INT,
	  [Page Lock Wait (ms)] INT,
	  [Missing Index] VARCHAR(1),
	  [Collection Time] DATETIME
    );
INSERT INTO #results		
exec sp_MSforeachdb 'USE [?];
		SELECT TOP 20
		@@SERVERNAME AS [Server Name],
		DB_NAME() AS [Database Name],
        OBJECT_NAME(o.object_id, o.database_id) AS [Object Name],
        o.index_id AS [Index ID],
        partition_number AS [Partition Number],
        page_lock_wait_count AS [Page Lock Wait Count],
        page_lock_wait_in_ms AS [Page Lock Wait (ms)],
        CASE WHEN mid.database_id IS NULL THEN ''N''
             ELSE ''Y''
        END AS missing_index_identified, CURRENT_TIMESTAMP AS [Collection Time]
FROM    sys.dm_db_index_operational_stats(DB_ID(), NULL, NULL, NULL) o
        LEFT OUTER JOIN ( SELECT DISTINCT
                                    database_id,
                                    object_id
                          FROM      sys.dm_db_missing_index_details
                        ) AS mid ON mid.database_id = o.database_id
                                    AND mid.object_id = o.object_id
ORDER BY page_lock_wait_count DESC OPTION (RECOMPILE);'
SELECT * FROM #results WHERE [Database Name] NOT IN ('master','model','msdb','tempdb') ORDER BY [Page Lock Wait (ms)] DESC
DROP TABLE #results
	