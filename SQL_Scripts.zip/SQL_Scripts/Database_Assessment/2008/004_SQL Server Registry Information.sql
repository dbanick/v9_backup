
/* SQL Server Registry Information */
SELECT @@SERVERNAME AS [Server Name], registry_key AS [Registry Key], value_name AS [Value Name], value_data AS [Value Data], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_server_registry WITH (NOLOCK) OPTION (RECOMPILE);
