
/* Database Corruption */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [File ID] INT,
	  [Page ID] INT,
	  [Page Status] VARCHAR(255),
	  [Modification Time] DATETIME,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME AS [Server Name], db_name() AS [Database Name], file_id AS [File ID], page_id AS [Page Id], page_status AS [Page Status], modification_time [Modification Time], CURRENT_TIMESTAMP AS [Collection Time]
FROM    sys.dm_db_mirroring_auto_page_repair
WHERE   modification_time >= DATEADD(dd, -30, CURRENT_TIMESTAMP) OPTION (RECOMPILE);';
SELECT * FROM #results ORDER BY [Database Name];
DROP TABLE #results;

SELECT @@SERVERNAME AS [Server Name], DB_NAME(database_id) AS [Database Name], file_id AS [File ID], page_id AS [Page ID], event_type AS [Event Type], CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb.dbo.suspect_pages
WHERE event_type IN (1,2,3) ORDER BY [Database Name] OPTION (RECOMPILE);
