
/* Enterprise Features in Use */
/* Reference: http://www.sqlskills.com/blogs/paul/post/SQL-Server-2008-Does-my-database-contain-Enterprise-only-features.aspx */
CREATE TABLE #output
    (
      [Server Name] VARCHAR(128),
      [Database Name] VARCHAR(128),
      [Enterprise Feature] VARCHAR(128),
	 [Collection Time] DATETIME
    )  
EXEC dbo.sp_MSforeachdb @command1 = 'USE [?]; INSERT INTO #output
SELECT @@SERVERNAME AS [Server Name], db_name() AS [Database Name], feature_name AS [Enterprise Feature], CURRENT_TIMESTAMP AS [Collection Time] FROM sys.dm_db_persisted_sku_features';
SELECT * FROM #output;
DROP TABLE #output;
