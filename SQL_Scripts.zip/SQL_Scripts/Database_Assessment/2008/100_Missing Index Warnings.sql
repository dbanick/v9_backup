
/* Missing Index Warnings */
/* Will run in all databases */
CREATE TABLE #RDXoutput
    (
      [Server Name] varchar(128),
      [Database Name] varchar(128),
      [Object Name] VARCHAR(128),
	  [Plan Handle] VARCHAR(128),
	  [Object Type] VARCHAR(128),
	  [Use Count] int,
	  [Collection Time] datetime
    )  
EXEC dbo.sp_MSforeachdb @command1 = 'USE [?]; INSERT INTO #RDXoutput
SELECT TOP (25)
	@@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
    OBJECT_NAME(objectid) AS [Object Name],
    --query_plan AS [Query Plan],
    plan_handle AS [Plan Handle],
    cp.objtype AS [Object Type],
    cp.usecounts AS [Use Count],
    CURRENT_TIMESTAMP AS [Collection Time]
FROM
    sys.dm_exec_cached_plans AS cp
    CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE
    CAST(query_plan AS NVARCHAR(MAX)) LIKE N''%MissingIndex%''
    AND dbid = DB_ID()
ORDER BY
    cp.usecounts DESC
OPTION
    (RECOMPILE);';

SELECT * FROM #RDXoutput

drop table #RDXoutput