
/* Processor Description */
CREATE TABLE #RDXResults
	(value VARCHAR(255), data VARCHAR(255));
INSERT INTO #RDXResults
EXEC xp_instance_regread 'HKEY_LOCAL_MACHINE','HARDWARE\DESCRIPTION\System\CentralProcessor\0','ProcessorNameString';
SELECT @@SERVERNAME AS [Server Name], value AS [Value Name], data AS [Processor Information], CURRENT_TIMESTAMP AS [Collection Time] FROM #RDXResults;
DROP TABLE #RDXResults;
