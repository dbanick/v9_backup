
/* SQL Server Properties */
SELECT 
	 SERVERPROPERTY('MachineName') AS [Machine Name], SERVERPROPERTY('ServerName') AS [Server Name]  
	,SERVERPROPERTY('InstanceName') AS [Instance], SERVERPROPERTY('IsClustered') AS [Is Clustered] 
	,SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS [Computer Name Physical NetBIOS]
	,SERVERPROPERTY('Edition') AS [Edition], SERVERPROPERTY('ProductLevel') AS [Product Level]
	,SERVERPROPERTY('ProductVersion') AS [Product Version], SERVERPROPERTY('ProcessID') AS [Process ID]
	,SERVERPROPERTY('Collation') AS [Collation], SERVERPROPERTY('IsFullTextInstalled') AS [Is Full Text Installed]
	,SERVERPROPERTY('IsIntegratedSecurityOnly') AS [Is Integrated Security Only]
	,SERVERPROPERTY('IsHadrEnabled') AS [Is HADR Enabled],SERVERPROPERTY('HadrManagerStatus') AS [HADR Manager Status]
	,CURRENT_TIMESTAMP AS [Collection Time];
