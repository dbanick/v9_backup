/* Backup History */
DECLARE @days INT;
SET @days = 60;
IF EXISTS (SELECT TOP 1 backup_set_id FROM msdb.dbo.backupset bs
			 WHERE bs.backup_start_date <= DATEADD(dd, -@days, CURRENT_TIMESTAMP)
			 ORDER BY backup_set_id ASC)
    SELECT @@SERVERNAME AS [Server Name], 'Consider purging your backup history. You have more than ' + CAST(@days AS VARCHAR(MAX)) + ' days of backup history in the msdb database.' AS [Backup History], CURRENT_TIMESTAMP AS [Collection Time];
ELSE
    SELECT @@SERVERNAME AS [Server Name], 'You have less than ' + CAST(@days AS VARCHAR(MAX)) + ' days of backup history in the msdb database.' AS [Backup History], CURRENT_TIMESTAMP AS [Collection Time];