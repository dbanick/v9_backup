
/* Default Trace Detail */
SELECT
	@@SERVERNAME AS [Server Name],
	t.DatabaseName AS [Database Name],
    te.name AS [Event Name] ,
    cat.name AS [Category Name],
    t.DatabaseID AS [Database ID],
    t.NTDomainName AS [NT Domain Name],
    t.ApplicationName AS [Application Name],
    t.LoginName AS [Login Name],
    t.Duration AS [Duration],
    t.StartTime AS [Start Time],
    t.EndTime AS [End Time],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM
    sys.fn_trace_gettable(CONVERT(VARCHAR(150), ( SELECT TOP 1
                                                    f.[value]
                                                  FROM
                                                    sys.fn_trace_getinfo(NULL) f
                                                  WHERE
                                                    f.property = 2
                                                )), DEFAULT) T
    JOIN sys.trace_events te ON t.EventClass = te.trace_event_id
    JOIN sys.trace_categories AS cat ON te.category_id = cat.category_id
WHERE te.category_id IN (2,3)
AND t.StartTime > DATEADD(dd, -30, CURRENT_TIMESTAMP)
ORDER BY [Start Time] DESC OPTION (RECOMPILE);
