
/* ----------------------------------------------------------------------------------------------------------
SQL Server Security
---------------------------------------------------------------------------------------------------------- */

/* Logins with Password Older than 60 Days */
SELECT @@SERVERNAME AS [Server Name], NAME AS [Login Name], LOGINPROPERTY([name], 'PasswordLastSetTime') AS 'Password Last Changed', CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.sql_logins
WHERE
    LOGINPROPERTY([name], 'PasswordLastSetTime') < DATEADD(dd, -60, CURRENT_TIMESTAMP)
    AND NOT ( LEFT([name], 2) = N'##'
              AND RIGHT([name], 2) = N'##'
            ) OPTION (RECOMPILE);
 