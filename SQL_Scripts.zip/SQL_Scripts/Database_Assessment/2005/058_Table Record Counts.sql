/* Table Record Counts */
CREATE TABLE #output
	(
	  [Server Name] VARCHAR(128),
	  [Database Name] VARCHAR(128),
	  [Object Name] VARCHAR(260),
	  [Row Count] INT,
	  [Collection Time] DATETIME
	);
INSERT INTO #output
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT @@SERVERNAME, DB_NAME(), OBJECT_NAME(object_id), SUM(Rows), CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.partitions 
WHERE index_id < 2 --ignore the partitions from the non-clustered index if any
AND OBJECT_NAME(object_id) NOT LIKE ''sys%''
AND OBJECT_NAME(object_id) NOT LIKE ''queue_%'' 
AND OBJECT_NAME(object_id) NOT LIKE ''filestream_tombstone%''
AND OBJECT_NAME(object_id) NOT LIKE ''fulltext%'' 
AND OBJECT_NAME(object_id) NOT LIKE N''ifts_comp_fragment%''
GROUP BY [object_id]
ORDER BY SUM(Rows) DESC OPTION (RECOMPILE);';
SELECT * FROM #output;
DROP TABLE #output;