
/* Sessions with orphaned transactions */
SELECT 
		@@SERVERNAME AS [Server Name],
		des.host_name AS [Host Name],
		des.session_id AS [Session ID],
		des.program_name AS [Program Name],
        des.login_time AS [Login Time],
        des.last_request_start_time AS [Last Request Start Time],
        des.last_request_end_time AS [Last Request End Time],
        des.login_name AS [Login Name],
        DATEDIFF(dd,des.login_time,des.last_request_end_time) AS [Days Orphaned],
		CURRENT_TIMESTAMP AS [Collection Time] 
FROM    sys.dm_exec_sessions des
        INNER JOIN sys.dm_tran_session_transactions dtst
                       ON des.session_id = dtst.session_id
        LEFT JOIN sys.dm_exec_requests der
                       ON dtst.session_id = der.session_id
WHERE   der.session_id IS NULL
ORDER BY [Days Orphaned] DESC OPTION (RECOMPILE);

