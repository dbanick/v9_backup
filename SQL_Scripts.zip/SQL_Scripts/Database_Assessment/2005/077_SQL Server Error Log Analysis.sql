
/* SQL Server Error Log Analysis */
CREATE TABLE #results
    (
	  [Log Date] DATETIME,
	  [Process Info] VARCHAR(255),
	  [Text] VARCHAR(5000)
    ) ;
INSERT INTO #results execute xp_readerrorlog 0, 1
SELECT @@SERVERNAME AS [Server Name], [Log Date], [Process Info], [Text], CURRENT_TIMESTAMP AS [Collection Time] FROM #results ORDER BY [Log Date] DESC
DROP TABLE #results

