
/* Database Corruption */
SELECT @@SERVERNAME AS [Server Name], DB_NAME(database_id) AS [Database Name], file_id AS [File ID], page_id AS [Page ID], event_type AS [Event Type], CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb.dbo.suspect_pages
WHERE event_type IN (1,2,3) ORDER BY [Database Name] OPTION (RECOMPILE);
