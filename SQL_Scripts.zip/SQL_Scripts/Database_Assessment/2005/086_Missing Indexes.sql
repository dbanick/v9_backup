
/* Missing Indexes */
CREATE TABLE #RDXDATA
    (
	   [Impact] BIGINT,
	   [Server Name] VARCHAR(255),
	   [Database.Schema.Table] VARCHAR(255),
	   [Table Name] VARCHAR(255),
	   [Last User Seek] DATETIME,
	   [Average Total User Cost] NUMERIC(10,2),
	   [Estimated % Reduction of Cost] BIGINT,
	   [Missed Opportunities] BIGINT,
	   [Equality Columns] VARCHAR(MAX),
	   [Inequality Columns] VARCHAR(MAX),
	   [Included Columns] VARCHAR(MAX),
	   [Total Rows] BIGINT,
	   [Collection Time] DATETIME
    )
INSERT INTO #RDXDATA
EXEC sp_MSforeachdb 'USE [?];
SELECT
    DISTINCT CAST((avg_total_user_cost * avg_user_impact) * (user_seeks + user_scans) AS BIGINT) AS [Impact],
    @@SERVERNAME AS [Server Name],
    mid.[statement] AS [Database.Schema.Table],
    OBJECT_NAME(mid.object_id) AS [Table Name],
    migs.last_user_seek AS [Last User Seek],
    CAST(migs.avg_total_user_cost AS NUMERIC(10,2)) AS [Average Total User Cost],
    CAST(migs.avg_user_impact AS BIGINT) AS [Estimated % Reduction of Cost],
    migs.user_seeks + migs.user_scans AS [Missed Opportunities],
    mid.equality_columns AS [Equality Columns],
    mid.inequality_columns AS [Inequality Columns],
    mid.included_columns AS [Included Columns],
    p.rows AS [Total Rows],
    CURRENT_TIMESTAMP AS [Collection Time]
FROM
    sys.dm_db_missing_index_group_stats AS migs WITH ( NOLOCK )
    INNER JOIN sys.dm_db_missing_index_groups AS mig WITH ( NOLOCK ) ON migs.group_handle = mig.index_group_handle
    INNER JOIN sys.dm_db_missing_index_details AS mid WITH ( NOLOCK ) ON mig.index_handle = mid.index_handle
    INNER JOIN sys.partitions AS p WITH ( NOLOCK ) ON mid.object_id = p.object_id
WHERE CAST((avg_total_user_cost * avg_user_impact) * (user_seeks + user_scans) AS BIGINT) >= 50000
AND mid.database_id = DB_ID()
ORDER BY [Impact] DESC OPTION (RECOMPILE);'
SELECT [Server Name], [Impact], [Database.Schema.Table], [Table Name], [Last User Seek], [Average Total User Cost], [Estimated % Reduction of Cost], [Missed Opportunities], [Equality Columns], [Inequality Columns], [Included Columns], [Total Rows], [Collection Time] 
FROM #RDXDATA ORDER BY [Impact] DESC;
DROP TABLE #RDXDATA;
