/* IO Statistics by File */
CREATE TABLE #output
    (
      [Server Name] VARCHAR(128),
      [Database Name] VARCHAR(128),
	  [File ID] INT,
	  num_of_reads BIGINT,
	  num_of_writes BIGINT,
	  io_stall_read_ms BIGINT,
	  io_stall_write_ms BIGINT,
	  io_stall_reads_pct DECIMAL(10,1),
	  io_stall_writes_pct DECIMAL(10,1),
	  writes_plus_reads BIGINT,
	  num_of_bytes_read BIGINT,
	  num_of_bytes_written BIGINT,
	  num_of_reads_pct DECIMAL(10,1),
	  num_of_writes_pct DECIMAL(10,1),
	  read_bytes_pct DECIMAL(10,1),
	  written_bytes_pct DECIMAL(10,1),
	  [Collection Time] DATETIME
    )
INSERT INTO #output 
exec sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME, DB_NAME(DB_ID()), [file_id], num_of_reads, num_of_writes, 
io_stall_read_ms, io_stall_write_ms,
CAST(100. * io_stall_read_ms/(io_stall_read_ms + io_stall_write_ms) AS DECIMAL(10,1)) AS [io_stall_reads_pct],
CAST(100. * io_stall_write_ms/(io_stall_write_ms + io_stall_read_ms) AS DECIMAL(10,1)) AS [io_stall_writes_pct],
(num_of_reads + num_of_writes) AS [writes_plus_reads], num_of_bytes_read, num_of_bytes_written,
CAST(100. * num_of_reads/(num_of_reads + num_of_writes) AS DECIMAL(10,1)) AS [num_of_reads_pct],
CAST(100. * num_of_writes/(num_of_reads + num_of_writes) AS DECIMAL(10,1)) AS [num_of_writes_pct],
CAST(100. * num_of_bytes_read/(num_of_bytes_read + num_of_bytes_written) AS DECIMAL(10,1)) AS [read_bytes_pct],
CAST(100. * num_of_bytes_written/(num_of_bytes_read + num_of_bytes_written) AS DECIMAL(10,1)) AS [written_bytes_pct], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_io_virtual_file_stats(DB_ID(), NULL) OPTION (RECOMPILE);'

SELECT * FROM #output
DROP TABLE #output