/* Sessions with Context Switching */
SELECT  
		@@SERVERNAME AS [Server Name],
		session_id AS [Session ID],
        login_name AS [Login Name],
        original_login_name AS [Original Login Name],
		CURRENT_TIMESTAMP AS [Collection Time] 
FROM    sys.dm_exec_sessions
WHERE   is_user_process = 1
        AND login_name <> original_login_name OPTION (RECOMPILE);
