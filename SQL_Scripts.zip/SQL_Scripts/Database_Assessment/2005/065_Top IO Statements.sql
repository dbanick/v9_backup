
/* Top Statements by Average IO */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [SP Name] VARCHAR(255),
	  [Avg IO] BIGINT,
	  [Query Text] VARCHAR(MAX),
	  [Collection Time] DATETIME
    );
INSERT INTO #results 		
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT TOP(10) @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], OBJECT_NAME(qt.objectid) AS [SP Name],
(qs.total_logical_reads + qs.total_logical_writes) /qs.execution_count AS [Avg IO],
LEFT(SUBSTRING(REPLACE(REPLACE(REPLACE([Text], CHAR(10), CHAR(32)), CHAR(13), CHAR(32)), CHAR(9), CHAR(32)),qs.statement_start_offset/2, 
	(CASE 
		WHEN qs.statement_end_offset = -1 
	 THEN LEN(CONVERT(NVARCHAR(MAX), REPLACE(REPLACE(REPLACE([Text], CHAR(10), CHAR(32)), CHAR(13), CHAR(32)), CHAR(9), CHAR(32)))) * 2 
		ELSE qs.statement_end_offset 
	 END - qs.statement_start_offset)/2),1500) AS [Query Text], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
WHERE qt.[dbid] = DB_ID()
ORDER BY [Avg IO] DESC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Avg IO] DESC
DROP TABLE #results
