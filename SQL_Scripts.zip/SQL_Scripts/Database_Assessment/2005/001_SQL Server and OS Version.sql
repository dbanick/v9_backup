

/* SQL Server Version and Operating System Version Information */
SELECT 
	 @@SERVERNAME AS [Server Name]
	,REPLACE(REPLACE(REPLACE(@@VERSION, CHAR(10), CHAR(32)), CHAR(13), CHAR(32)), CHAR(9), CHAR(32)) AS [SQL Server and OS Version Info]
	,(SELECT create_date FROM sys.databases WHERE database_id = 2) AS [Last SQL Server Restart]
	,CURRENT_TIMESTAMP AS [Collection Time];
