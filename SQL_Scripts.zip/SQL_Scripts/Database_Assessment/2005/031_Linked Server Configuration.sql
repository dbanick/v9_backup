
/* Linked Server Configuration */
/* If they have linked serves check their security for SA use */
SELECT @@SERVERNAME AS [Server Name], name AS [Linked Server Name], '' AS [Is Using SA], CURRENT_TIMESTAMP AS [Collection Time] 
FROM master.sys.servers
WHERE is_linked = 1 OPTION (RECOMPILE);
