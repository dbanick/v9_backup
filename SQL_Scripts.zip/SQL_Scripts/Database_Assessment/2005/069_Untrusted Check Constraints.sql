
/* Untrusted Check Constraints */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
	  [Database Name] VARCHAR(255),
	  [Object Name] VARCHAR(255),
	  [Object Create Date] DATETIME,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC dbo.sp_MSforeachdb 'USE [?]; 
		SELECT @@SERVERNAME AS [Server Name],
		db_name() AS [Database Name],
		s.name + ''.'' + o.name + ''.'' + i.name AS [Index Name], o.create_date, CURRENT_TIMESTAMP AS [Collection Time] 
		from [?].sys.check_constraints i 
		INNER JOIN [?].sys.objects o ON i.parent_object_id = o.object_id 
		INNER JOIN [?].sys.schemas s ON o.schema_id = s.schema_id 
		WHERE i.is_not_trusted = 1 AND i.is_not_for_replication = 0 AND i.is_disabled = 0 OPTION (RECOMPILE);';
SELECT * FROM #results ORDER BY [Database Name] 
DROP TABLE #results
