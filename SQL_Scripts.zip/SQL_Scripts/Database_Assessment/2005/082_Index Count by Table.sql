
/* Index Count by Table */
/* Only counts non-clustered indexes */
/* Doesn't count hypothetical indexes */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Table Name] VARCHAR(255),
	  [Count] INT,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT  @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], o.name AS [Table Name],
        ( SELECT    COUNT(*)
          FROM      sys.indexes i
          WHERE     i.object_id = o.object_id
                    AND i.index_id > 1
                    AND i.is_hypothetical = 0
        ) AS [Index Count], CURRENT_TIMESTAMP AS [Collection Time]
FROM    sys.objects o
WHERE   o.type = ''U''
ORDER BY [Index Count] DESC OPTION (RECOMPILE);';
SELECT * FROM #results WHERE [Database Name] NOT IN ('master','model','msdb','tempdb') ORDER BY [Count]
DROP TABLE #results
