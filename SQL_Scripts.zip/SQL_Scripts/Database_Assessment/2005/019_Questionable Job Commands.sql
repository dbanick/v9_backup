
/* Questionable SQL Server Agent Job Commands */
SELECT @@SERVERNAME AS [Server Name], j.name AS [Job Name], js.step_name AS [Step Name], j.[enabled] AS [Enabled], CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb.dbo.sysjobs j
	INNER JOIN msdb.dbo.sysjobsteps js ON j.job_id = js.job_id
    WHERE js.command 
		LIKE N'%SHRINKDATABASE%' 
		OR js.command LIKE N'%SHRINKFILE%'
		OR js.command LIKE N'%KILL%'
		OR js.command LIKE N'FREEPROCCACHE%'
		OR js.command LIKE N'FREESYSTEMCACHE%'
		OR js.command LIKE N'FREESESSIONCACHE%'
		OR js.command LIKE N'SHUTDOWN%'
		OR js.command LIKE N'RECONFIGURE%'
		OR js.command LIKE N'%SHRINK%'
		OR js.command LIKE N'%TRUNCATE_ONLY%';  
