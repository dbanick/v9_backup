
/* Index Read & Write Statistics - Ordered by Writes */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Table Name] VARCHAR(255),
	  [Index Name] VARCHAR(255),
	  [Index Id] INT,
	  [Reads] BIGINT,
	  [Writes] BIGINT,
	  [Index Type] VARCHAR(255),
	  [Fill Factor] INT,
	  [Collection Time] DATETIME
    ) ;
EXEC sp_MSforeachdb @command1 = 'USE [?]; INSERT INTO #results
SELECT @@SERVERNAME AS [Server Name], db_name() AS [Database Name], OBJECT_NAME(s.[object_id]) AS [Table Name], i.name AS [Index Name], i.index_id AS [Index Id],
	   user_seeks + user_scans + user_lookups AS [Reads], s.user_updates AS [Writes],  
	   i.type_desc AS [IndexType], i.fill_factor AS [FillFactor], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
WHERE OBJECTPROPERTY(s.[object_id],''IsUserTable'') = 1
AND i.index_id = s.index_id
AND s.database_id = DB_ID()
ORDER BY s.user_updates DESC OPTION (RECOMPILE);'
SELECT * FROM #results WHERE [Database Name] NOT IN ('tempdb','master','model','msdb') ORDER BY [Writes] DESC
DROP TABLE #results
