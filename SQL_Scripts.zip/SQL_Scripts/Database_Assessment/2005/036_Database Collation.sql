
/* ----------------------------------------------------------------------------------------------------------
SQL Server Database Configuration 
---------------------------------------------------------------------------------------------------------- */

/* Check User Database Collation Against Tempdb Collation */
SELECT  
	@@SERVERNAME AS [Server Name]
	,d.name AS [Database Name]
	,d.collation_name AS [Database Collation Name]
	,CONVERT(VARCHAR(100), SERVERPROPERTY('collation')) AS [Server Collation Name]
	,CURRENT_TIMESTAMP AS [Collection Time] 
FROM master.sys.databases d
WHERE d.name NOT IN ('master','model','msdb') 
AND d.name NOT LIKE 'ReportServer%' 
AND d.collation_name <> ( SELECT collation_name
							FROM sys.databases
							WHERE name = 'tempdb') OPTION (RECOMPILE);
