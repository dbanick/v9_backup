
/* Databases without Log Backup */
SELECT DISTINCT 
		@@SERVERNAME AS [Server Name], d.name AS [Database Name], d.state_desc AS [Database State], d.recovery_model_desc AS [Recovery Model], 'None in last 7 days.' AS [Transaction Log Backup], CURRENT_TIMESTAMP AS [Collection Time] 
FROM master.sys.databases d
WHERE d.recovery_model IN (1,2)
	AND d.[state] <> 1 
	AND d.is_in_standby = 0
    AND d.source_database_id IS NULL
    AND NOT EXISTS (SELECT * FROM msdb.dbo.backupset b WHERE  d.name = b.database_name
                     AND b.type = 'L' AND b.backup_finish_date >= DATEADD(dd, -7, CURRENT_TIMESTAMP)) OPTION (RECOMPILE);
