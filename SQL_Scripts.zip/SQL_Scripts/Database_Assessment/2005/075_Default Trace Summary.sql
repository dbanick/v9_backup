
/* Default Trace Summary */
SELECT
	@@SERVERNAME AS [Server Name],
	t.DatabaseName [Database Name],
    te.name AS [Event Name],
    COUNT(te.name) AS [Count],
    SUM(t.Duration) AS [Total Duration],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM
    sys.fn_trace_gettable(CONVERT(VARCHAR(150), ( SELECT TOP 1
                                                    f.[value]
                                                  FROM
                                                    sys.fn_trace_getinfo(NULL) f
                                                  WHERE
                                                    f.property = 2
                                                )), DEFAULT) T
    JOIN sys.trace_events te ON t.EventClass = te.trace_event_id
    JOIN sys.trace_categories AS cat ON te.category_id = cat.category_id
WHERE te.category_id IN (2,3)
AND t.StartTime > DATEADD(dd, -30, CURRENT_TIMESTAMP)
GROUP BY te.name, t.databasename
ORDER BY [Database Name], [Event Name] OPTION (RECOMPILE);
