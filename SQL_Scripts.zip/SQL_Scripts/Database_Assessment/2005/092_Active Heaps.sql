
/* Active Heaps */
CREATE TABLE #rdxresults
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Schema] VARCHAR(255),
	  [Table Name] VARCHAR(255),
	  [Rows] INT,
	  [User Seeks] BIGINT,
	  [User Scans] BIGINT,
	  [User Lookups] BIGINT,
	  [User Updates] BIGINT,
	  [Last User Seek] DATETIME,
	  [Last User Scan] DATETIME,
	  [Last User Lookup] DATETIME,
	  [Collection Time] DATETIME
    ) ;
EXEC dbo.sp_MSforeachdb 'USE [?]; INSERT INTO #rdxresults
SELECT @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], SCHEMA_NAME(o.schema_id) AS [Schema], OBJECT_NAME(i.object_id) AS [Table Name], p.rows AS [Rows],
    user_seeks AS [User Seeks] ,
    user_scans AS [User Scans] ,
    user_lookups AS [User Lookups] ,
    user_updates AS [User Updates] ,
    last_user_seek AS [Last User Seek] ,
    last_user_scan AS [Last User Scan] ,
    last_user_lookup AS [Last User Lookup],
    CURRENT_TIMESTAMP AS [Collection Time]
	FROM [?].sys.indexes i INNER JOIN [?].sys.objects o ON i.object_id = o.object_id INNER JOIN [?].sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id INNER JOIN sys.databases sd ON sd.name = ''?'' LEFT OUTER JOIN [?].sys.dm_db_index_usage_stats ius ON i.object_id = ius.object_id AND i.index_id = ius.index_id AND ius.database_id = sd.database_id WHERE i.type_desc = ''HEAP'' AND COALESCE(ius.user_seeks, ius.user_scans, ius.user_lookups, ius.user_updates) IS NOT NULL AND sd.name <> ''tempdb'' AND o.is_ms_shipped = 0
	ORDER BY p.rows DESC OPTION (RECOMPILE);'
SELECT * FROM #rdxresults ORDER BY rows DESC
DROP TABLE #rdxresults
