
/* Database Auto Growth Settings */
SELECT 
	@@SERVERNAME AS [Server Name],
	db.name AS [Database Name],
	db.state_desc AS [Database State],
	mf.type_desc AS [File Type], 
	mf.state_desc AS [File State],
    mf.name AS [Logical File Name], 
	fg.name AS [File Group Name],
	mf.physical_name AS [Physical File Name], 
	mf.is_percent_growth AS [Is Percent Growth], 
	CASE 
        WHEN mf.is_percent_growth = 0 
            THEN LTRIM(STR(mf.growth * 8.0 / 1024,10,1)) + ' MB, ' 
        ELSE
            'Autogrow By ' + CAST(mf.growth AS VARCHAR) + ' Percent, '
    END + 
    CASE 
        WHEN mf.max_size = -1 THEN 'Unrestricted growth'
        ELSE 'Restricted growth to ' + 
            LTRIM(STR(mf.max_size * 8.0 / 1024,10,1)) + ' MB' 
    END AS [Autogrowth Configuration],
	CONVERT(BIGINT, mf.size/128.0) AS [Total File Size in MB],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.master_files AS mf WITH (NOLOCK)
	LEFT JOIN sys.filegroups AS fg WITH (NOLOCK) ON mf.data_space_id = fg.data_space_id
	LEFT JOIN sys.databases AS db WITH (NOLOCK) ON mf.database_id = db.database_id
ORDER BY db.name OPTION (RECOMPILE);
