
/* Unhardened Instance Configuration Settings */
SELECT @@SERVERNAME AS [Server Name], cr.[name] AS [Name], cr.value AS [Current Value], cr.value_in_use AS [Value in Use], 
is_advanced AS [Is Advanced], is_dynamic AS [Is Dynamic], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.configurations cr
WHERE (cr.value <> cr.value_in_use) AND NOT (name = 'min server memory (MB)' and value = 0 and value_in_use = 16)
