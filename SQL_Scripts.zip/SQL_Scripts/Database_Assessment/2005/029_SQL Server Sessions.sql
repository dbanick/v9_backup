  
/* SQL Server Sessions */
SELECT @@SERVERNAME AS [Server Name], login_name AS [Login Name], COUNT(session_id) AS [Session Count], is_user_process AS [User Process], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_sessions
GROUP BY login_name, is_user_process
ORDER BY COUNT(session_id) DESC
OPTION (RECOMPILE);
