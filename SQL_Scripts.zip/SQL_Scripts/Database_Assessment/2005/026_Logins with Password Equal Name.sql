
/* Check for sql logins with password the same as the login name */
SELECT @@SERVERNAME AS [Server Name], name AS [Login Name] , type_desc AS [Login Type], create_date AS [Date Created], modify_date AS [Date Modified], is_disabled AS [Is Disabled], CURRENT_TIMESTAMP AS [Collection Time]  
FROM sys.sql_logins WHERE PWDCOMPARE(name, password_hash) = 1
OR PWDCOMPARE(name, password_hash, 1) = 1 OPTION (RECOMPILE);
