
/* SQL Server Installation Date */   
SELECT @@SERVERNAME AS [Server Name], create_date AS [SQL Server Install Date], CURRENT_TIMESTAMP AS [Collection Time]  
FROM sys.server_principals WITH (NOLOCK)
WHERE name = N'NT AUTHORITY\SYSTEM'
OR name = N'NT AUTHORITY\NETWORK SERVICE' OPTION (RECOMPILE);
