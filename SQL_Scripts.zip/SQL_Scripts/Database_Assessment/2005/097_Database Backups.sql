
/* Database Backups */
SELECT  
		@@SERVERNAME AS [Server Name],
		SUBSTRING(s.name, 1, 40) AS [Database Name],
        CAST(b.backup_start_date AS CHAR(11)) AS [Backup Date],
        CASE WHEN b.backup_start_date > DATEADD(dd, -1, CURRENT_TIMESTAMP)
             THEN 'Backup is current within a day'
             WHEN b.backup_start_date > DATEADD(dd, -7, CURRENT_TIMESTAMP)
             THEN 'Backup is current within a week'
             ELSE '*****CHECK BACKUP!!!*****'
        END AS [Comment],
	   CURRENT_TIMESTAMP AS [Collection Time]
FROM    master.sys.databases s
        LEFT OUTER JOIN msdb..backupset b ON s.name = b.database_name
                                             AND b.backup_start_date = ( SELECT MAX(backup_start_date)
                                                                         FROM   msdb..backupset
                                                                         WHERE  database_name = b.database_name
                                                                                AND type = 'D'
                                                                       )		-- full database backups only, not log backups
WHERE   s.name <> 'tempdb'
ORDER BY s.name OPTION (RECOMPILE);
