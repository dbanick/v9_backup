
/* SPs by Total Physical Reads */
CREATE TABLE #results
(
	[Server Name] VARCHAR(255),
    [Database Name] VARCHAR(255),
	[SP Name] VARCHAR(1000),
	[Total Physical Reads] BIGINT,
	[Total Logical Reads] BIGINT,
	[Max Logical Reads] BIGINT,
	[Avg Logical Reads] BIGINT,
	[Execution Count] BIGINT,
	[Calls/Second] INT,
	[Avg Worker Time] BIGINT,
	[Total Worker Time] BIGINT,
	[Avg Elapsed Time] BIGINT,
	[Minutes in Cache] DATETIME,
	[Collection Time] DATETIME
);
INSERT INTO #results
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT TOP(10) @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], left(qt.[text],1000) AS [SP Name], qs.total_physical_reads, total_logical_reads, qs.max_logical_reads,
total_logical_reads/qs.execution_count AS [Avg Logical Reads], qs.execution_count AS [Execution Count], 
qs.execution_count/DATEDIFF(Second, qs.creation_time, CURRENT_TIMESTAMP) AS [Calls/Second], 
qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
qs.total_worker_time AS [Total Worker Time],
qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
DATEDIFF(Minute, qs.creation_time, CURRENT_TIMESTAMP) AS [Minutes in Cache], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.[sql_handle]) AS qt
WHERE qt.[dbid] = DB_ID() -- Filter by current database
AND qs.total_physical_reads > 0
ORDER BY qs.total_physical_reads DESC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Total Physical Reads] DESC
DROP TABLE #results
