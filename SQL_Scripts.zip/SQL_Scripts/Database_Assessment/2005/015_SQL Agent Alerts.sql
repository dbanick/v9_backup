 
/* SQL Agent Alerts */
SELECT @@SERVERNAME AS [Server Name], name AS [Alert Name], event_source AS [Event Source], message_id AS [Message Id], job_id AS [Job ID], severity AS [Severity], 
[enabled] AS [Alert Enabled], has_notification AS [Has Notification], delay_between_responses AS [Delay Between Responses], occurrence_count AS [Occurence Count], 
last_occurrence_date AS [Last Occurrence Date], last_occurrence_time AS [Last Occurrence Time], CURRENT_TIMESTAMP AS [Collection Time] 
FROM msdb..sysalerts OPTION (RECOMPILE);
