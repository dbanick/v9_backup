
/* Maximum Data Loss */
/* We are looking at the last 14 days of backups */
CREATE TABLE #backupset (backup_set_id INT, database_name NVARCHAR(128), backup_finish_date DATETIME, [type] CHAR(1), next_backup_finish_date DATETIME);
INSERT INTO #backupset (backup_set_id, database_name, backup_finish_date, [type])
    SELECT backup_set_id, database_name, backup_finish_date, type
	   FROM msdb.dbo.backupset WITH (NOLOCK)
	   WHERE backup_finish_date >= DATEADD(dd, -14, CURRENT_TIMESTAMP)
		  AND database_name NOT IN ('master', 'msdb');
CREATE CLUSTERED INDEX CL_database_name_backup_finish_date ON #backupset (database_name, backup_finish_date);

UPDATE #backupset
SET next_backup_finish_date = (SELECT TOP 1 backup_finish_date FROM #backupset bsNext WHERE bs.database_name = bsNext.database_name AND bs.backup_finish_date < bsNext.backup_finish_date ORDER BY bsNext.backup_finish_date)
FROM #backupset bs;

SELECT @@SERVERNAME AS [Server Name], bs1.database_name AS [Database Name], MAX(DATEDIFF(mi, bs1.backup_finish_date, bs1.next_backup_finish_date)) AS [Max Minutes of Data Loss], CURRENT_TIMESTAMP AS [Collection Time]
    FROM #backupset bs1
    GROUP BY bs1.database_name
    ORDER BY bs1.database_name;
DROP TABLE #backupset;
