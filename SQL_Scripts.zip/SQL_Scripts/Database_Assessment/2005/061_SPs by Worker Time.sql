
/* SPs by Total Worker Time */
CREATE TABLE #results
(
	[Server Name] VARCHAR(255),
    [Database Name] VARCHAR(255),
	[SP Name] VARCHAR(1000),
	[Total Worker Time] BIGINT,
	[Avg Worker Time] BIGINT,
	[Execution Count] BIGINT,
	[Calls/Second] BIGINT,
	[Avg Elapsed Time] BIGINT,
	[Total Elapsed Time] BIGINT,
	[Max Logical Reads] BIGINT,
	[Max Logical Writes] BIGINT,
	[Minutes in Cache] INT,
	[Collection Time] DATETIME
);
INSERT INTO #results	
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT TOP(10) @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], left(qt.[text],1000) AS [SP Name], qs.total_worker_time AS [Total Worker Time], 
qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
qs.execution_count AS [Execution Count], 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.creation_time, CURRENT_TIMESTAMP), 0) AS [Calls/Second],
ISNULL(qs.total_elapsed_time/qs.execution_count, 0) AS [Avg Elapsed Time], 
qs.total_elapsed_time,
qs.max_logical_reads, qs.max_logical_writes, 
DATEDIFF(Minute, qs.creation_time, CURRENT_TIMESTAMP) AS [Minutes in Cache], CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.[sql_handle]) AS qt
WHERE qt.[dbid] = DB_ID()
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Total Worker Time] DESC
DROP TABLE #results
