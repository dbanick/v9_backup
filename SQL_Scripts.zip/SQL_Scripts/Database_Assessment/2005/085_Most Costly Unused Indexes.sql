
/* Most Costly Unused Indexes */
/* Where updates are greater that the sum of seeks, scans and lookups */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Object Name] VARCHAR(255),
	  [Index Name] VARCHAR(255),
	  [Index ID] INT,
	  [Total Writes] BIGINT,
	  [Total Reads] BIGINT,
	  [Difference] BIGINT,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], OBJECT_NAME(s.[object_id]) AS [Table Name], i.name AS [Index Name], i.index_id AS [Index ID],
user_updates AS [Total Writes], user_seeks + user_scans + user_lookups AS [Total Reads],
user_updates - (user_seeks + user_scans + user_lookups) AS [Difference], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
AND i.index_id = s.index_id
WHERE OBJECTPROPERTY(s.[object_id],''IsUserTable'') = 1
AND s.database_id = DB_ID()
AND user_updates > (user_seeks + user_scans + user_lookups)
AND i.index_id > 1
ORDER BY [Difference] DESC, [Total Writes] DESC, [Total Reads] ASC OPTION (RECOMPILE);'
SELECT * FROM #results ORDER BY [Total Reads]
DROP TABLE #results
