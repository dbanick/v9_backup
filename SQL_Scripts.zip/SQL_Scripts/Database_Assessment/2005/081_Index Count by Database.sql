
/* Index Count by Database */
/* Only counts non-clustered indexes */
/* Doesn't count hypothetical indexes */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Count] INT,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], count(index_id) AS [Index Count], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.indexes i
	INNER JOIN sys.objects o on i.object_id = o.object_id
WHERE i.index_id > 1 
	AND i.is_hypothetical = 0
	AND o.type = ''U'' OPTION (RECOMPILE);';
SELECT * FROM #results WHERE [Database Name] NOT IN ('master','model','msdb','tempdb') ORDER BY [Count];
DROP TABLE #results;
