
/* System Manufacturer and Model Number */
CREATE TABLE #RDXResults
	(logdate DATETIME, processinfo VARCHAR(255), [Text] VARCHAR(255));
INSERT INTO #RDXResults
EXEC xp_readerrorlog 0,1,"Manufacturer"; 
SELECT @@SERVERNAME AS [Server Name], logdate AS [Log Date], processinfo AS [Process Info], [Text] AS [System Manufacturer], CURRENT_TIMESTAMP AS [Collection Time] FROM #RDXResults;
DROP TABLE #RDXResults;
