
/* Page Life Expectancy */
/* This should be trended for maximum diagnostic benefit */
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 
SELECT 
@@SERVERNAME AS [Server Name],
	CASE ple.[Node]
		WHEN ' ' THEN 'Total PLE for all NUMA Nodes' 
		ELSE ple.[Node]	
	END AS [Numa Node] 
,LTRIM(STR([Page Life in Seconds]/3600))+':'+REPLACE(STR([Page Life in Seconds]%3600/60,2),SPACE(1),'0')+':'+REPLACE(STR([Page Life in Seconds]%60,2),SPACE(1),'0') AS [Page Life] 
,ple.[Page Life in Seconds] 
,dp.[Database Pages] [Buffer Pool Pages] 
,CONVERT(DECIMAL(15,3),dp.[Database Pages]*0.0078125) [Buffer Pool Size in MB] 
,CONVERT(DECIMAL(15,3),dp.[Database Pages]*0.0078125/[Page Life in Seconds]) [Buffer Pool MB/s]
,CURRENT_TIMESTAMP AS [Collection Time] 
FROM 
( 
SELECT [instance_name] [node],[cntr_value] [Page Life in Seconds] FROM sys.dm_os_performance_counters 
WHERE [counter_name] = 'Page life expectancy' 
) ple 
INNER JOIN 
( 
SELECT [instance_name] [node],[cntr_value] [Database Pages] FROM sys.dm_os_performance_counters 
WHERE [counter_name] = 'Database pages' 
) dp ON ple.[node] = dp.[node] OPTION (RECOMPILE);
