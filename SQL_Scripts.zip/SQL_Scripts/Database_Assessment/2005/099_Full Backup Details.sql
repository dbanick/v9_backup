/* Recent full backup details */
CREATE TABLE #rdxresults
	(
		[Server Name] VARCHAR(255),
		[Database Name] VARCHAR(255),
		[Uncompressed Backup Size (MB)] BIGINT,
		[Backup Elapsed Time (sec)] INT,
		[Backup Finish Date] DATETIME,
		[Collection Time] DATETIME
	);
INSERT INTO #rdxresults
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT TOP (30) bs.server_name AS [Server Name], bs.database_name AS [Database Name], 
CONVERT (BIGINT, bs.backup_size / 1048576 ) AS [Uncompressed Backup Size (MB)],
DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) AS [Backup Elapsed Time (sec)],
bs.backup_finish_date AS [Backup Finish Date], CURRENT_TIMESTAMP AS [Collection Time]
FROM msdb.dbo.backupset AS bs WITH (NOLOCK)
WHERE DATEDIFF (SECOND, bs.backup_start_date, bs.backup_finish_date) > 0 
AND bs.backup_size > 0
AND bs.type = ''D'' -- Change to L if you want Log backups
AND database_name = DB_NAME(DB_ID()) OPTION (RECOMPILE);';
SELECT * FROM #rdxresults ORDER BY [Database Name] ASC, [Backup Finish Date] ASC;
DROP TABLE #rdxresults;