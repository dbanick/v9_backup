
/* Hypothetical Indexes */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Schema Name] VARCHAR(255),
	  [Table Name] VARCHAR(255),
	  [Index Name] VARCHAR(255),
	  [Hypothetical] INT,
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME AS [Server Name], DB_NAME() AS [Database Name], SCHEMA_NAME(o.schema_id) AS [Schema Name], o.name AS [Table Name], i.name AS [Index Name], i.is_hypothetical AS [Hypothetical], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.objects AS o
	INNER JOIN sys.indexes AS i ON o.object_id = i.object_id
WHERE i.is_hypothetical = 1 OPTION (RECOMPILE);';
SELECT * FROM #results ORDER BY [Database Name]
DROP TABLE #results
