
/* Buffer Usage by Object */
SELECT
	@@SERVERNAME AS [Server Name],
    DB_NAME() AS [Database Name],
    OBJECT_NAME (p.[object_id]) AS [Table Name],
    p.[index_id] AS [Index ID],
    i.[name] AS [Index Name],
    i.[type_desc] AS [Index Type],
    (DPCount + CPCount) * 8 / 1024 AS [Total Size in MB],
    ([DPFreeSpace] + [CPFreeSpace]) / 1024 / 1024 AS [Free Space in MB],
    CAST (ROUND (100.0 * (([DPFreeSpace] + [CPFreeSpace]) / 1024) / (([DPCount] + [CPCount]) * 8), 1) AS DECIMAL (4, 1)) AS [Free Space Percent],
    CURRENT_TIMESTAMP AS [Collection Time] 
FROM
    (SELECT
        allocation_unit_id,
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 1 ELSE 0 END) AS [DPCount],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 0 ELSE 1 END) AS [CPCount],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN CAST ([free_space_in_bytes] AS BIGINT) ELSE 0 END) AS [DPFreeSpace],
        SUM (CASE WHEN ([is_modified] = 1)
            THEN 0 ELSE CAST ([free_space_in_bytes] AS BIGINT) END) AS [CPFreeSpace]
    FROM sys.dm_os_buffer_descriptors
    WHERE [database_id] = DB_ID()
    GROUP BY [allocation_unit_id]) AS buffers
INNER JOIN sys.allocation_units AS au
    ON au.[allocation_unit_id] = buffers.[allocation_unit_id]
INNER JOIN sys.partitions AS p
    ON au.[container_id] = p.[partition_id]
INNER JOIN sys.indexes AS i
    ON i.[index_id] = p.[index_id] AND p.[object_id] = i.[object_id]
WHERE p.[object_id] > 100 AND ([DPCount] + [CPCount]) > 12800 -- Taking up more than 100MB
--WHERE p.[object_id] > 100 AND ([DPCount] + [CPCount]) > 6400 -- Taking up more than 50MB
--WHERE p.[object_id] > 100 AND ([DPCount] + [CPCount]) > 3200 -- Taking up more than 25MB
ORDER BY [Free Space Percent] DESC OPTION (RECOMPILE);
