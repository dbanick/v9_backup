/*
/ Perform a 'USE <database name>' to select the database in which to run the script.
*/



-- Declare variables
SET NOCOUNT ON
DECLARE @maxfrag numeric(8,3)

-- Decide on the maximum fragmentation to allow
-- Below is the percentage the index has to be fragmented
-- Suggest to start at 30.0 (30%)
SELECT @maxfrag = 20.0


-- Create the table
CREATE TABLE #fraglist (
ObjectName varchar (255),
ObjectId int,
IndexName varchar (255),
IndexId int,
Lvl int,
CountPages int,
CountRows int,
MinRecSize int,
MaxRecSize int,
AvgRecSize int,
ForRecCount int,
Extents int,
ExtentSwitches int,
AvgFreeBytes int,
AvgPageDensity int,
ScanDensity numeric(8,3),
BestCount int,
ActualCount int,
LogicalFrag numeric(8,3),
ExtentFrag numeric(8,3)
)
-- Create the table
CREATE TABLE #fraglist2 (
database_name  varchar(255),
ObjectName varchar (255),
ObjectId int,
IndexName varchar (255),
IndexId int,
Lvl int,
CountPages int,
CountRows int,
MinRecSize int,
MaxRecSize int,
AvgRecSize int,
ForRecCount int,
Extents int,
ExtentSwitches int,
AvgFreeBytes int,
AvgPageDensity int,
ScanDensity numeric(8,3),
BestCount int,
ActualCount int,
LogicalFrag numeric(8,3),
ExtentFrag numeric(8,3)
)

exec sp_msforeachdb '
use [?]

DECLARE @tablename varchar (128)
DECLARE @execstr varchar (255)
DECLARE @objectid int
DECLARE @indexid int
DECLARE @frag numeric(8,3)

-- Declare cursor
DECLARE tables CURSOR FOR
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = ''BASE TABLE''
-- Do not scan common table indexes
AND TABLE_NAME NOT LIKE ''xdl%''
AND TABLE_NAME NOT LIKE ''Prf_%''

-- Open the cursor
OPEN tables

-- Loop through all the tables in the database
FETCH NEXT FROM tables INTO @tablename

WHILE (@@FETCH_STATUS = 0) BEGIN
-- Do the showcontig of all indexes of the table
INSERT INTO #fraglist
EXEC (''DBCC SHOWCONTIG ('''''' + @tablename + '''''') WITH FAST, TABLERESULTS, ALL_INDEXES, NO_INFOMSGS'')
FETCH NEXT FROM tables INTO @tablename
END

insert into #fraglist2
select db_name(), * from #fraglist

delete from #fraglist

-- Close and deallocate the cursor
CLOSE tables
DEALLOCATE tables
'
-- Declare cursor for list of indexes to be defragged
-- DECLARE indexes CURSOR FOR
SELECT * --database_name, ObjectName, ObjectId, IndexId, LogicalFrag
FROM #fraglist
WHERE LogicalFrag >= @maxfrag
AND INDEXPROPERTY (ObjectId, IndexName, 'IndexDepth') > 0

go
drop table  #fraglist
go
drop table  #fraglist2