use   tempdb 
create table #tmp_RDX_stats (
database_name varchar(1000),
table_Name  varchar(1000),
index_name varchar(1000),
statistics_date datetime
)

exec sp_MSforeachdb
'
use [?]

insert into tempdb.dbo.#tmp_RDX_stats
SELECT
        db_name() as [database], 
	o.name AS Table_Name
       ,i.name AS Index_Name
       ,STATS_DATE(o.id,i.indid) AS Date_Updated
FROM
        sysobjects o JOIN
        sysindexes i ON i.id = o.id
WHERE
        xtype = ''U'' AND 
		
        i.name IS NOT NULL 
		
ORDER BY
      date_updated desc
'

select * from #tmp_RDX_stats
GO
drop table  #tmp_RDX_stats