declare @startdate datetime,
@enddate datetime

set @startdate = DATEADD(DAY,-7, GETDATE())
set @enddate = GETDATE()


create table #rdxerrorlog (LogDate datetime, ProcessInfo varchar(25), Text varchar(max))

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Backup failed", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Login failed", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "A significant part of sql server memory has been paged out", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "A significant part of sql server process memory has been paged out", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Stack Signature", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "SUSPECT", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Could not allocate", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Autogrow of file", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Replication", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "I/O requests taking longer than 15 seconds", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "Disallowing page allocations for database", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "The transaction log for database", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "The operating system returned error", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "SQL Server is Starting", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 0, 1, "The error log has been reinitialized", null, @startdate, @enddate, "desc"

IF EXISTS (select [Text] from #rdxerrorlog where [Text] like 'SQL Server is starting%' OR [Text] like 'The error log has been reinitialized%')
 BEGIN
 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Backup failed", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Login failed", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "A significant part of sql server memory has been paged out", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "A significant part of sql server process memory has been paged out", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Stack Signature", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "SUSPECT", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Could not allocate", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Autogrow of file", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Replication", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "I/O requests taking longer than 15 seconds", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "Disallowing page allocations for database", null, @startdate, @enddate, "desc"
            
 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "SQL Server is Starting", null, @startdate, @enddate, "desc"

 insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
 EXEC master.dbo.xp_readerrorlog 1, 1, "The transaction log for database", null, @startdate, @enddate, "desc"

insert into #rdxerrorlog (LogDate, ProcessInfo, Text)
EXEC master.dbo.xp_readerrorlog 1, 1, "The operating system returned error", null, @startdate, @enddate, "desc"

 END

--SELECT * from #rdxerrorlog
--order by LogDate desc


select @@SERVERNAME as ServerName, Text, ProcessInfo as type, count(*) as count from #rdxerrorlog
group by Text, ProcessInfo
order by count desc

drop table #rdxerrorlog

/*
Backup failed
Login failed
A significant part of sql server memory has been paged out
A significant part of sql server process memory has been paged out
Stack Signature
SUSPECT
Could not allocate
Autogrow of file
Replication
I/O requests taking longer than 15 seconds
Disallowing page allocations for database
*/