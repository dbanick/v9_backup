
SELECT @@SERVERNAME AS [Server Name], cpu_count AS [Logical CPU Count], hyperthread_ratio AS [Hyperthread Ratio],
cpu_count/hyperthread_ratio AS [Physical CPU Count], 
physical_memory_kb/1024 AS [Physical Memory (MB)], 
sqlserver_start_time AS [SQL Server Start Time], affinity_type_desc AS [Affinity Type Description], 
virtual_machine_type_desc AS [Virtual Machine Type], CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_os_sys_info OPTION (RECOMPILE);